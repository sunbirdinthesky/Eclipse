package backGround;

public class AdministratorAccessChecker {

}
