package vars;

public class UploadIndex {
	public String imei;
	public int playCount;
}
