package vars;

public class Strings {
	static String AboutApplicationName = "";
}
