package vars;

import java.util.Vector;

import org.eclipse.swt.widgets.Button;


public class Vars {
	public static String ip = "192.168.1.40";//"192.168.20.40";//"119.29.68.158";// "192.168.1.44";
	public static int port = 21;
	public static String ftpName = "sunbird";
	public static String ftpPasswd = "a5018335686";

	public static String sqlName = "root";
	public static String sqlPasswd = "a5018335686";
	public static String now;
	public static String version = "1.1 beta";
	
	public static String filePath;

	public static Vector<AdFile> ads = new Vector<>();
	public static boolean adsFlag = true;
	public static Vector<AdFile> repeats = new Vector<>();
	public static boolean repeatsFlag = true;
	public static Vector<Device> Devices = new Vector<>();
	public static boolean DevicesFlag = true;
	public static Vector<Button> UploadDevices = new Vector<>();
	public static boolean UploadDevicesFlag = true;
}
